<?php	 		
	session_name("Administrador");
	session_start();		
	if ($_SESSION["EntityID"] == "")
	{
		header("Location:sessionexpired.php"); 	
	}	 				
		
	require('Library/Control_Cache.php');	
	require('Library/Open_Conexion.php');	
	require('Library/funciones.php');
				
	$Pro_ID = $_GET['Pro_ID'];	
		
	?>
	<fieldset id="Fs_Lista_Cliente" class="" >
		<legend>List of Stages: </legend>	
		 <form action="#" id="form_etapas_nuevo" name="form_etapas_nuevo">
			<table  width="100%" cellpadding="2" cellspacing="2">
				<tr>
				  <td>											
						<b>Name</b> <input type="text" id="Nombre" name="Nombre" value="" size="10" />
						<b>Effort %</b> 
						<input type="text"  name="Porcentaje_Esfuerzo" id="Porcentaje_Esfuerzo" value="" size="4" onblur='$("#Horas").val(  (this.value*($("#Aux_Horas").val()))/100   );' /> 						
						<b>Hours</b> 
						<input name="Horas" type="text" id="Horas" value="" size="4" onblur='$("#Porcentaje_Esfuerzo").val(  (this.value*100)/($("#Aux_Horas").val())   );' />								
						<b>Star Date:</b> 
						<input  type="text" id="Fecha_Inicio_Etapa" name="Fecha_Inicio_Etapa" value="" size="10"  datepicker="true" datepicker_format="MM-DD-YYYY" readonly="" />
						<img src="images/spacer.gif" onload='DatePickerControl.createButton(document.getElementById("Fecha_Inicio_Etapa"));' /> 
						
						<b>End Date:</b> 
						<input  type="text" id="Fecha_Fin_Etapa" name="Fecha_Fin_Etapa" value="" size="10"  datepicker="true" datepicker_format="MM-DD-YYYY" readonly=""/>
						<img src="images/spacer.gif" onload='DatePickerControl.createButton(document.getElementById("Fecha_Fin_Etapa"));' /> 						
						<input name="Etapas_ID" type="hidden" id="Etapas_ID" value=""/>
						<input name="Pro_ID" type="hidden" id="Pro_ID" value="<?php echo $Pro_ID; ?>" size="4" />	
						<span id="span_bnt_New">
							<INPUT id="button" type="button" value="Add" name="button" onClick="Empresas_Proyectos_Etapas_Registrar();">   					
						</span> 
						<span id="span_bnt_save" style="display:none">
							<INPUT id="button" type="button" value="Save" name="button" onClick="Empresas_Proyectos_Etapas_Editar_Guardar();">   
							<INPUT id="button" type="button" value="Cancel" name="button" onClick="Empresas_Proyectos_Etapas_Editar_Cancelar();"> 					
						</span>
				</tr>					
			</table>						
		</form>	
		<div id="Div_Empresas_Proyectos_Etapas_Lista">
		</div>	
	</fieldset>
<?php
	echo "<img src='images/spacer.gif' onload='Empresas_Proyectos_Etapas_Lista($Pro_ID);' />"; 		
	require('Library/Close_Conexion.php');
?>