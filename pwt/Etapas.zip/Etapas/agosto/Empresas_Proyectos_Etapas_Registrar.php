<?php	 		
	session_name("Administrador");
	session_start();		
	if ($_SESSION["EntityID"] == "")
	{
		header("Location:sessionexpired.php"); 	
	}	 	
		
	require('Library/Control_Cache.php');	
	require('Library/Open_Conexion.php');	
	require('Library/funciones.php');	
				         					  
	foreach($_POST as $nombre_campo => $valor)
	{
	   	
	   	if  ( !empty($valor )  )
			$asignacion = "\$" . $nombre_campo . "='" . $valor . "';";			
		else
			$asignacion = "\$" . $nombre_campo . "='';";			
			
	   	eval($asignacion);
	} 	
	$Fecha_Inicio_Etapa=ConvertDateToMysqlFormat($Fecha_Inicio_Etapa);
	$Fecha_Fin_Etapa=ConvertDateToMysqlFormat($Fecha_Fin_Etapa);
	
	$consulta = "SELECT * FROM etapas WHERE Pro_ID=".$Pro_ID." AND ( (Fecha_Inicio BETWEEN '".$Fecha_Inicio_Etapa."' AND '".$Fecha_Fin_Etapa."') OR (Fecha_Fin BETWEEN  '".$Fecha_Inicio_Etapa."' AND '".$Fecha_Fin_Etapa."') ) AND Etapas_ID!=".$Etapas_ID; 
	//echo $consulta."<br>";
	$contador=0;	 	  	 	  	  

	$result2=$bd->ejecutar($consulta); 	
	if (($row2 = mysql_fetch_array($result2) ))							
	{		
		echo "ERROR Fechas incluidas en otras etapas ";
	?>
		<img src='images/icon_recargar.gif' onclick='Empresas_Proyectos_Etapas_Lista(<?php echo $Pro_ID; ?>);' />
	<?php
	}
	else
	{	
		$Horas_Etapa=$Horas;	
		$total_dias_habiles = Dias_Habiles($Fecha_Inicio_Etapa,$Fecha_Fin_Etapa, $bd);							
		//echo "<bR>$Fecha_Inicio_Etapa***$Fecha_Fin_Etapa***$total_dias_habiles";
		$Horas_Dia = round($Horas_Etapa/$total_dias_habiles);					
		$Empleados_Diarios = round($Horas_Dia/8);
		
		$strSQL = "INSERT INTO etapas (Pro_ID, Nombre, Porcentaje_Esfuerzo, Fecha_Inicio, Fecha_Fin, Empleados_Diarios, Horas, Dias_Habiles) ";	
		$strSQL = $strSQL . " values (".$Pro_ID.",'" . $Nombre . "','" . $Porcentaje_Esfuerzo. "','" . $Fecha_Inicio_Etapa. "','" . $Fecha_Fin_Etapa. "','" . $Empleados_Diarios. "','" . $Horas . "'," . $total_dias_habiles . ")";		
		//echo $strSQL."<br>";				
		$res1=$bd->ejecutar($strSQL);  		
		if ($res1)
		{		
			echo "Saved"; 	
			echo "<img src='images/spacer.gif' onload='Empresas_Proyectos_Etapas_Lista($Pro_ID);' />"; 
		}
		else
		{
			echo "ERROR";	
		?>
			<img src='images/icon_recargar.gif' onclick='Empresas_Proyectos_Etapas_Lista(<?php echo $Pro_ID; ?>);' />
		<?php
		}
	}
	mysql_free_result($result2);	
	
	require('Library/Close_Conexion.php');	
?>