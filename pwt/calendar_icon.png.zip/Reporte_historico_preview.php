<?php

	session_name("Administrador");
	session_start();
		

	if ($_SESSION["EntityID"] == "")
	{
		header("Location:sessionexpired.php"); 
	}	

	require('Library/Control_Cache.php');
	require('Library/Open_Conexion.php');
	require('Library/funciones.php');
	
	require('pdf/fpdf.php');
	$pdf=new FPDF('L','mm','A4');
	$pdf->AddPage();
	
	// DEFINICION DE FUNCIONES DE CABEZERA DE SUBCUEPO

	$pdf->SetMargins(15,20,15,15);
	$pdf->SetFont('Arial','',10);
	$pdf->SetLineWidth(0.5); 
	$pdf->Setfillcolor(237,243,120);
	
	function membrete(&$pdf)
	{
		//ENCABEZADO
		$pdf->SetFont('Arial','',8);
		$pdf->Image('images/logo.png',5,5,30,10,"png");
		$pdf->SetFont('Arial','',10);
	}
	
	function encabezado(&$pdf,$f1,$f2)
	{

	  $f1=FormatDateTime($f1, 8);
	  $f2=FormatDateTime($f2, 8);
  	  $pdf->Multicell(0,5,"",0,L,false);
	  $pdf->Multicell(0,5,"Report: History Record/Job By Person",0,C,false);
  	  $pdf->Multicell(0,5,"from:".$f1." to:".$f2,0,C,false);
  	  $pdf->Multicell(0,5,"",0,L,false);
	  // titulo del detall	

  	  $aux=$pdf->GetY();
	  $pdf->SetX(20);
	  $pdf->Multicell(0,5,"Nro. Employe",0,L,false);
	  
	  $pdf->SetY($aux);
	  $pdf->SetX(40);
	  $pdf->Multicell(0,5,"Employe",0,L,false);

	  $pdf->SetY($aux);
	  $pdf->SetX(60);
	  $pdf->Multicell(0,5,"Nombre Trabajo",0,L,false);

	  $pdf->SetY($aux);
	  $pdf->SetX(80);
	  $pdf->Multicell(25,5,"Hours in Contract",0,C,false);

	  $pdf->SetY($aux);
	  $pdf->SetX(100);
	  $pdf->Multicell(25,5,"Codigo Coste",0,C,false);

	  $pdf->SetY($aux);
	  $pdf->SetX(163);
	  $pdf->Multicell(20,5,"Date",0,C,false);

	  $pdf->SetY($aux);
	  $pdf->SetX(120);
	  $pdf->Multicell(30,5,"Hour Contract",0,C,false);

  	  $pdf->SetY($aux);
  	  $pdf->SetX(140);
	  $pdf->Multicell(23,5,"Hour TM",0,C,false);	
		
		$pdf->SetY($aux);
  		$pdf->SetX(160);
		$pdf->Multicell(23,5,"Hour In",0,C,false);

		$pdf->SetY($aux);
  		$pdf->SetX(180);
		$pdf->Multicell(23,5,"Foto In",0,C,false);.
		
		$pdf->SetY($aux);
  		$pdf->SetX(200);
		$pdf->Multicell(23,5,"Clave",0,C,false);
		
		$pdf->SetY($aux);
  		$pdf->SetX(220);
		$pdf->Multicell(23,5,"GPS",0,C,false);
		
		$pdf->SetY($aux);
  		$pdf->SetX(240);
		$pdf->Multicell(23,5,"Hour Out",0,C,false);
		
		$pdf->SetY($aux);
  		$pdf->SetX(260);
		$pdf->Multicell(23,5,"Foto Out",0,C,false);
		
		$pdf->SetY($aux);
  		$pdf->SetX(280);
		$pdf->Multicell(23,5,"Clave",0,C,false);
		
		$pdf->SetY($aux);
  		$pdf->SetX(300);
		$pdf->Multicell(23,5,"GPS",0,C,false);

	  $aux7=$pdf->GetY();
	  $pdf->line(10,$pdf->GetY()-10,200,$pdf->GetY()-10);
  	  $pdf->line(10,$aux+10,200,$aux+10);
	  $pdf->SetY($aux7+10);	  

	}

	
	$Empleado_ID=$_SESSION["Empleado_ID"];		
	$vfrom_date=$_GET["vfrom_date"];
	$vto_date=$_GET["vto_date"];
	$Nick_Name=$_GET["Nick_Name"];
	$Estilo="";
	
	$vdia=substr($vfrom_date,3,2);
	$vmes=substr($vfrom_date,0,2);
	$vano=substr($vfrom_date,8,2);
	$af1="20".$vano."-".$vmes."-".$vdia;	

	$vdia=substr($vto_date,3,2);
	$vmes=substr($vto_date,0,2);
	$vano=substr($vto_date,8,2);
	$af2="20".$vano."-".$vmes."-".$vdia;
	
	membrete($pdf);
	encabezado($pdf,$af1,$af2);
		
	
?> 
<table border="1" cellpadding="0" cellspacing="0" id="mitabla" width="100%">	
	<?php		
			
	$sql = "(SELECT   pr.Aux1, pr.Codigo,  pr.Nombre AS Proyecto, t.Task_ID, a.Area_ID, a.Floor_ID, e.Edificio_ID,
			Fecha, Horas_Contract, Horas_TM, Detalles, RDA_ID, p.Nombre AS Nombre_Empleado, Apellido_Paterno, Apellido_Materno,
			p.Empleado_ID, rd.Reg_ID, ADDTIME(Hora_Ingreso, '-04:00:00.000') AS Hora_Ingreso, ADDTIME(Hora_Salida, '-04:00:00.000') AS Hora_Salida,  
			Verificado_Foreman, Foto_Ingreso,Foto_Salida,Latitud_Ingreso,Latitud_Salida,Longitud_Ingreso,Longitud_Salida,Pregunta_IN,Pregunta_OUT,Clave_Digitada_In,Clave_Digitada_Out, TIMEDIFF(Hora_Salida,Hora_Ingreso) AS Horas ";
	$sql = $sql . " FROM registro_diario rd INNER JOIN registro_diario_actividad rda ON rd.Reg_ID=rda.Reg_ID AND rd.Fecha BETWEEN '".$af1."' AND '".$af2."' ";
	$sql = $sql . " INNER JOIN task t ON rda.Task_ID=t.Task_ID ";
	$sql = $sql . " INNER JOIN area_control a ON t.Area_ID=a.Area_ID ";
	$sql = $sql . " INNER JOIN floor f ON f.Floor_ID=a.Floor_ID ";
	$sql = $sql . " INNER JOIN edificios e ON e.Edificio_ID=f.Edificio_ID ";
	$sql = $sql . " INNER JOIN personal p ON p.Empleado_ID=rd.Empleado_ID ";
	if ($Nick_Name!="")	
		$sql = $sql . " AND p.Nick_Name like '%$Nick_Name%' ";	
	$sql = $sql . " INNER JOIN proyectos pr ON t.Pro_ID=pr.Pro_ID ";			
	//$sql = $sql . " ORDER BY p.Apellido_Paterno, p.Apellido_Materno, p.Nombre ) UNION ";	
	$sql = $sql . " ) UNION ";	
	
	
	$sql = $sql .  "(SELECT pr.Aux1, pr.Codigo, pr.Nombre AS Proyecto, -1 AS Task_ID, -1 AS Area_ID, -1 AS Floor_ID, -1 AS Edificio_ID, '2017-01-01' AS Fecha, -1 AS Horas_Contract,-1 AS Horas_TM, '-1' AS Detalles, -1 AS RDA_ID,p.Nombre, p.Apellido_Paterno, p.Apellido_Materno, p.Empleado_ID, -1 AS Reg_ID, '01:01:00' AS Hora_Ingreso, '01:01:00' AS Hora_Salida, 1 AS Verificado_Foreman, '-1' AS Foto_Ingreso, '-1' AS Foto_Salida, '-1' AS Latitud_Ingreso, '-1' AS Latitud_Salida,'-1' AS Longitud_Ingreso, '-1' AS Longitud_Salida, '-1' AS Pregunta_IN, '-1' AS Pregunta_OUT, '-1' AS Clave_Digitada_In, '-1' AS Clave_Digitada_Out, -1 AS Horas  ";
	$sql = $sql .  " FROM actividades a ";
	$sql = $sql .  " INNER JOIN proyectos pr ON pr.Pro_ID=a.Pro_ID ";
	$sql = $sql .  " INNER JOIN actividad_personal ap ON ap.Actividad_ID=a.Actividad_ID ";
	$sql = $sql .  " INNER JOIN personal p ON p.Empleado_ID=ap.Empleado_ID ";
	if ($Nick_Name!="")	
		$sql = $sql . " AND p.Nick_Name like '%$Nick_Name%' ";	
	$sql = $sql .  " WHERE (  (a.Fecha BETWEEN '".$af1."' AND '".$af2."') OR (a.Fecha='2013-01-01') ) ";	
	$sql = $sql .  " AND   p.Empleado_ID NOT IN ( SELECT Empleado_ID FROM registro_diario WHERE Fecha BETWEEN '".$af1."' AND '".$af2."'  ) ";		
	//$sql = $sql .  " ORDER BY 1,13) UNION ";
	$sql = $sql .  " ) UNION ";
		
	
	$sql = $sql . "(SELECT   pr.Aux1, pr.Codigo, pr.Nombre AS Proyecto, -1 AS Task_ID, -1 AS Area_ID, -1 AS Floor_ID, -1 AS Edificio_ID, rd.Fecha, -1 AS Horas_Contract, -1 AS Horas_TM, '-1' AS Detalles, -1 AS RDA_ID,p.Nombre, p.Apellido_Paterno, p.Apellido_Materno, p.Empleado_ID, Reg_ID, ADDTIME(Hora_Ingreso, '-04:00:00.000') AS Hora_Ingreso, ADDTIME(Hora_Salida, '-04:00:00.000') AS Hora_Salida, 1 AS Verificado_Foreman, Foto_Ingreso, Foto_Salida, Latitud_Ingreso, Latitud_Salida, Longitud_Ingreso, Longitud_Salida, Pregunta_IN, Pregunta_OUT, Clave_Digitada_In, Clave_Digitada_Out, TIMEDIFF(Hora_Salida,Hora_Ingreso) AS Horas ";
	$sql = $sql . " FROM personal p ";
	$sql = $sql . " INNER JOIN  registro_diario rd  ON p.Empleado_ID=rd.Empleado_ID AND rd.Fecha BETWEEN '".$af1."' AND '".$af2."'";
	
	if ($Nick_Name!="")	
		$sql = $sql . " AND p.Nick_Name like '%$Nick_Name%' ";	
		
	$sql = $sql .  " AND   rd.Reg_ID NOT IN ( SELECT Reg_ID FROM registro_diario_actividad ) ";
	$sql = $sql .  " INNER JOIN proyectos pr ON pr.Pro_ID=rd.Pro_ID ";		
	
	$sql = $sql . " ORDER BY 1,13 )  ";
			
	
	//echo $sql."<br>";													
	$result77=$bd->ejecutar($sql); 	
	if(mysql_num_rows($result)>0)
	{		
		$RDA_ID=-1;
		$Fila=1;
		$Empleado_ID = "";
		
		$Empleado_ID_Ant = -77;
		$Total_Horas_Contract=0;
		$Total_Horas_TM=0;
		
		while (($row77 = mysql_fetch_array($result77) ))	
		{
			
			$Aux1=$row77["Aux1"];
			$Codigo=$row77["Codigo"];
			$Proyecto=$row77["Proyecto"];
			
			$Task_ID=$row77["Task_ID"];
			$Area_ID=$row77["Area_ID"];
			$Floor_ID=$row77["Floor_ID"];
			$Edificio_ID=$row77["Edificio_ID"];		
			$Fecha=$row77["Fecha"];		
			$Horas_Contract=$row77["Horas_Contract"];
			$Horas_TM=$row77["Horas_TM"];
			$Detalles=$row77["Detalles"];
			$RDA_ID=$row77["RDA_ID"];
			$Nombre_Empleado=$row77["Nombre_Empleado"];
			$Apellido_Paterno=$row77["Apellido_Paterno"];
			$Apellido_Materno=$row77["Apellido_Materno"];
			$Empleado_ID=$row77["Empleado_ID"];
			
			$Hora_Ingreso=$row77["Hora_Ingreso"];
			$Hora_Salida=$row77["Hora_Salida"];
			$Verificado_Foreman=$row77["Verificado_Foreman"];
			$Reg_ID=$row77["Reg_ID"];			
			
			$Foto_Ingreso=$row77["Foto_Ingreso"];
			$Foto_Salida=$row77["Foto_Salida"];
			
			$Latitud_Ingreso=$row77["Latitud_Ingreso"];
			$Latitud_Salida=$row77["Latitud_Salida"];
			
			$Longitud_Ingreso=$row77["Longitud_Ingreso"];
			$Longitud_Salida=$row77["Longitud_Salida"];
			
			$Pregunta_IN=$row77["Pregunta_IN"];
			$Pregunta_OUT=$row77["Pregunta_OUT"];
			
			$Clave_Digitada_In=$row77["Clave_Digitada_In"];
			$Clave_Digitada_Out=$row77["Clave_Digitada_Out"];

			
			$Horas_aux=$row["Horas"];
			
			if ($Empleado_ID_Ant ==-77)
				$Empleado_ID_Ant = $Empleado_ID;
			
			
			$array = split(":", $Horas_aux);
			
			if ( $array[1]<31 )
				$Horas=$array[0]+0.5;
			else
				$Horas=$array[0]+1;	
			
			
			$Empleados_ID = $Empleados_ID . $Empleado_ID . ",";
						
			$_SESSION["RDA_ID"]=$RDA_ID;
			
			$estado_foreman="";
			if ( ($Verificado_Foreman=="1") || ($Verificado_Foreman==true))
			{
				//echo $Verificado_Foreman."<br>";
				$estado_foreman="checked='checked'";
			}		
			
			if (($Hora_Ingreso=="-04:00:00")	|| ($Hora_Ingreso=="00:00:00"))						
				$Hora_Ingreso="";
				
			if (($Hora_Salida=="-04:00:00")	|| ($Hora_Salida=="00:00:00"))								
				$Hora_Salida="";
			
			$Se_Saco_Foto="S";		
			if (is_null($Foto_Ingreso))								
				$Se_Saco_Foto="N";	
				
				
			/*if ($Empleado_ID_Ant!=	$Empleado_ID)
			{
				echo "<tr><td colspan=6 border=0>TOTAL</td><td>".$Total_Horas_Contract."</td><td>".$Total_Horas_TM."</td>";
				echo "</table><br>";
				
				$Total_Horas_Contract=0;
				$Total_Horas_TM=0;
				
				echo "<table border='1' cellpadding='0' cellspacing='0' id='mitabla' width='100%'>
					<tr align='center'>
						<td>Nro. Employe</td><td>Employe</td><td>Nro. Trabajo</td><td>Nombre Trabajo</td><td>Codigo Coste</td>
						<td>Fecha</td><td>Hour Contract</td><td>Hour TM</td><td>Hour In</td><td>Foto S/N</td><td>Hour Out</td>
					</tr>";
					
			}*/
	?>
	
			<tr>
				<td><?php echo $Aux1; ?></td>
				<td><?php echo $Nombre_Empleado. " ".$Apellido_Paterno. " ".$Apellido_Materno; ?></td>
                <td><?php echo $Codigo; ?></td>
                <td><?php echo $Proyecto; ?></td>				
				<td >							 
					<?php		
							if ($Edificio_ID!=-1)
							{
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Edificio_ID=".$Edificio_ID;	
								//echo $sql."<br>";														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
									$Edificio=$row["Nombre"];
								}
								mysql_free_result($result);	
								
								$sql = "select Floor_ID, Nombre FROM floor WHERE Floor_ID=".$Floor_ID;														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
									$Piso=$row["Nombre"];								
								}
								mysql_free_result($result);	
								
								$sql = "select Area_ID, Nombre FROM area_control WHERE Area_ID=".$Area_ID;														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
									$Area=$row["Nombre"];								
								}
								mysql_free_result($result);
								
								$sql = "select Task_ID, Nombre FROM area_control WHERE Task_ID=".$Task_ID;														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
									$Tarea=$row["Nombre"];								
								}
								mysql_free_result($result);
								
								echo $Edificio."-".$Piso."-".$Area."-".$Tarea;	
							}							
					?>									
                </td>
                <td><?php echo $Fecha; ?></td>	                    		
				<td ><?php echo $Horas_Contract; ?></td>		
				<td ><?php echo $Horas_TM; ?></td>				
                <td><?php echo $Hora_Ingreso; ?></td>
                <td><img src="fotos/<?php echo $Foto_Ingreso; ?>" height="50" width="50" /></td>
                <td><?php echo $Clave_Digitada_In; ?></td>
                <td><a href="http://maps.google.com?q=<?php echo $Latitud_Ingreso.",".$Longitud_Ingreso; ?>" target="_blank"><?php echo $Latitud_Ingreso.",".$Longitud_Ingreso; ?></a></td>                               
                       
				<td><?php echo $Hora_Salida; ?></td>				
                <td><img src="fotos/<?php echo $Foto_Salida; ?>" height="50" width="50" /></td>
                <td><?php echo $Clave_Digitada_Out; ?></td>
                <td><a href="http://maps.google.com?q=<?php echo $Latitud_Salida.",".$Longitud_Salida; ?>" target="_blank"><?php echo $Latitud_Salida.",".$Longitud_Salida; ?></a>
				</td>
                
			</tr>
	<?php
			$Empleado_ID_Ant=$Empleado_ID;
			$Total_Horas_Contract=$Total_Horas_Contract+$Horas_Contract;
			$Total_Horas_TM=$Total_Horas_TM+$Horas_TM;
			$Fila++;
			
		}
	
	}
	mysql_free_result($result77);

	$pdf->Output("dato.pdf");
?>

	<embed src="dato.pdf#toolbar=1&navpanes=0&scrollbar=0" width="1190" height="570"></embed> 
</table>
	
<?php	
	require('Library/Close_Conexion.php');	
?>