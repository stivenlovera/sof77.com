
<?php	 		

	session_name("Administrador");
	session_start();
	if ($_SESSION["EntityID"] == "")
	{
		header("Location:sessionexpired.php"); 	
	}	
		
	require('Library/Control_Cache.php');
	require('Library/Open_Conexion.php');
	require('Library/funciones.php');				         					  		

	$Reg_ID=$_GET["Reg_ID"];
	
	$Task_ID_var=$_GET["Task_ID"];
	$Horas_Contract=$_GET["Horas_Contract"];
	$Horas_TM=$_GET["Horas_TM"];
	$Detalle=$_GET["Detalle"];
	$RDA_ID=$_GET["RDA_ID"];	
	$Empleado_ID=$_GET["Empleado_ID"];	
	$Reg_ID=$_GET["Reg_ID"];
	$Verificado_Foreman=$_GET["Verificado_Foreman"];
	$Hora_Ingreso=$_GET["Hora_Ingreso"];
	$Hora_Salida=$_GET["Hora_Salida"];

	$Task_ID_s = explode("|", $Task_ID_var);
	$Horas_Contract_s = explode("|", $Horas_Contract);
	$Horas_TM_s = explode("|", $Horas_TM);
	$Detalle_s = explode("|", $Detalle);
	$RDA_ID_s = explode("|", $RDA_ID);
	$Empleado_ID_s = explode("|", $Empleado_ID);
	$Verificado_Foreman_s = explode("|", $Verificado_Foreman);
	$Reg_ID_s = explode("|", $Reg_ID);
	$Date_Work=$_SESSION["Date_Work"];
	
	$Hora_Ingreso_s = explode("|", $Hora_Ingreso);
	$Hora_Salida_s = explode("|", $Hora_Salida);
	
	//echo $Task_ID_s[0]; 
	//echo "llego 0"."<br>";
	$i=0;
	foreach ($Task_ID_s as &$Task_ID) // Poner Registro Maestro Vacio
	{
		//echo "llego 1"."<br>";
		//echo $Verificado_Foreman_s[$i]."<br>";
		//if ($Task_ID_s[$i]!="-1")
		if ($Task_ID!="-1")
		{
			//echo "llego 2"."<br>";
			if ($RDA_ID_s[$i]=="-1")
			{	
				//echo "llego 3"."<br>";
				$Reg_ID=$Reg_ID_s[$i];
				//echo $Reg_ID."<br>";
				//echo $Reg_ID_s[$i]."<br>";
				if ($Reg_ID_s[$i]==-1)
				{
					//echo "llego 4"."<br>";
					$strSQL = "INSERT INTO registro_diario (Empleado_ID,  Fecha, Pro_ID, Hora_Ingreso, Hora_Salida) ";	
					$strSQL = $strSQL . " values (".$Empleado_ID_s[$i].", '".$Date_Work."',".$_SESSION["Pro_ID"].", ADDTIME('".$Hora_Ingreso_s[$i]."', '04:00:00.000'),  ADDTIME('".$Hora_Salida_s[$i]."', '04:00:00.000'))";		
					$result2=$bd->ejecutar($strSQL);
					
					//echo $strSQL."<br>";
					
					if ($result2)
					{
						$sql = "SELECT Reg_ID FROM registro_diario ORDER BY Reg_ID DESC";														
						$result=$bd->ejecutar($sql); 		
						if (($row = mysql_fetch_array($result) ))	
						{									
							$Reg_ID=$row["Reg_ID"];
						}
						mysql_free_result($result);							
					}
					else
						$Reg_ID=-1;
				}
				
				if ($Reg_ID!=-1)
				{
					$strSQL = "UPDATE registro_diario  SET Hora_Ingreso=ADDTIME('".$Hora_Ingreso_s[$i]."', '04:00:00.000'), Hora_Salida=ADDTIME('".$Hora_Salida_s[$i]."', '04:00:00.000')";	
					$strSQL = $strSQL . " WHERE Reg_ID=".$Reg_ID;	
					$result2=$bd->ejecutar($strSQL);
					//echo $strSQL."<br>";
					
					//echo "INSERT INTO registro_diario_actividad "."<br>";	
					$strSQL = "INSERT INTO registro_diario_actividad (Reg_ID, Task_ID, Horas_Contract, Horas_TM, Detalles, Verificado_Foreman) ";	
					$strSQL = $strSQL . " values (".$Reg_ID.",".$Task_ID.",'".$Horas_Contract_s[$i]."','".$Horas_TM_s[$i]."','".$Detalle_s[$i]."',".$Verificado_Foreman_s[$i].")";	
					$result2=$bd->ejecutar($strSQL);
					//echo $strSQL."<br>";						 
				}
			}
			else
			{
				//echo "UPDATE registro_diario_actividad  "."<br>";	
				if ($RDA_ID_s[$i]!=-1)
				{	
					$strSQL = "UPDATE registro_diario  SET Hora_Ingreso=ADDTIME('".$Hora_Ingreso_s[$i]."', '04:00:00.000'), Hora_Salida=ADDTIME('".$Hora_Salida_s[$i]."', '04:00:00.000')";	
					$strSQL = $strSQL . " WHERE Reg_ID=".$Reg_ID_s[$i];	
					$result2=$bd->ejecutar($strSQL);
					//echo $strSQL."<br>";
									
					$strSQL = "UPDATE registro_diario_actividad  SET Task_ID=".$Task_ID.", Horas_Contract='".$Horas_Contract_s[$i]."', Horas_TM='".$Horas_TM_s[$i]."', Detalles='".$Detalle_s[$i]."', Verificado_Foreman=".$Verificado_Foreman_s[$i];	
					$strSQL = $strSQL . " WHERE RDA_ID=".$RDA_ID_s[$i];	
					$result2=$bd->ejecutar($strSQL);
					//echo $strSQL."<br>";
				}
			}			
		}
		else
		{				
			if ($RDA_ID_s[$i]!=-1)
			{					
				//echo "DELETE FROM registro_diario_actividad "."<br>";	
				$strSQL = "DELETE FROM registro_diario_actividad  ";	
				$strSQL = $strSQL . " WHERE RDA_ID=".$RDA_ID_s[$i];	
				$result2=$bd->ejecutar($strSQL);
			}
		}
		
		$sql = "SELECT SUM(Horas_Contract) AS Horas_Contract, SUM(Horas_TM) AS Horas_TM FROM registro_diario_actividad WHERE Reg_ID IN (SELECT Reg_ID FROM registro_diario WHERE Empleado_ID=".$Empleado_ID_s[$i]." AND Fecha='".$Date_Work."')";														
		$result89=$bd->ejecutar($sql); 
		//echo $sql."<br>";
		$Horas_Contract="";
		$Horas_TM="";		
		if (($row89 = mysql_fetch_array($result89) ))	
		{									
			$Horas_Contract=$row89["Horas_Contract"];
			$Horas_TM=$row89["Horas_TM"];
		}
		mysql_free_result($result89);
		$strSQL = "UPDATE actividad_personal SET HContract=".$Horas_Contract.", HTM=".$Horas_TM." WHERE Empleado_ID=".$Empleado_ID_s[$i]." AND Actividad_ID IN (SELECT Actividad_ID FROM actividades WHERE Pro_ID=".$_SESSION["Pro_ID"]." AND Fecha='".$Date_Work."') ";	
		$result89=$bd->ejecutar($strSQL);
		//echo $strSQL."<br>";
			
		$i++;	
	}	
	
	//echo $strSQL;
	if ($result2)
		echo "Registro Satisfactorio.";
	else
		echo "Error en Registro";

	require('Library/Close_Conexion.php');	

?>