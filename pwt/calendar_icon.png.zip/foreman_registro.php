<?php

	session_name("Administrador");
	session_start();		

	if ($_SESSION["EntityID"] == "")
	{
		header("Location:sessionexpired.php"); 	
	}	

	require('Library/Control_Cache.php');	
	require('Library/Open_Conexion.php');	
	require('Library/funciones.php');	

	$Empleado_ID=$_SESSION["Empleado_ID"];
	//echo $_SESSION["Empleado_ID"];			
	require('funciones_php/foreman.php');
	require('funciones_php/empleado.php');	
?>
<meta name="viewport" content="width=device-width, user-scalable=no">
<LINK href="include/Stat.css" type="text/css" rel="stylesheet">
<link rel="STYLESHEET" type="text/css" href="include/estilo_reporte.css">


<LINK href="include/jquery-ui.css" type="text/css" rel="stylesheet">
<LINK href='include/demo.css' type='text/css' rel='stylesheet' media='screen' />


<script type="text/javascript" src="include/jquery-1.9.1.js"></script>
<script type="text/javascript" src="include/jquery-ui.1.10.3.js"></script>
<script type="text/javascript" src="include/iAjax.js"></script>
		

<script type="text/javascript" src="include/getAjax.js"></script> 
<script type="text/javascript" src="include/funciones.js"></script>
<!-- Contact Form CSS files -->

<link type='text/css' href='css/basic.css' rel='stylesheet' media='screen' />

<script type="text/javascript">	
	var Latitud="";
	var Longitud="";
	function SendEnter (event) {
			var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
			if (keyCode == 13) {		
					postAx('foreman_validaPassword2.php','user='+document.ss.username.value+'&pass='+document.ss.password.value+'&Pro_ID='+document.ss.Pro_ID.value+'&Reg_ID='+document.ss.Reg_ID.value,'passWrong',15);			
			} 
			else
			return true;
		}   
	
	function SendClick () 
	{
		postAx('foreman_validaPassword2.php','user='+document.ss.username.value+'&pass='+document.ss.password.value+'&Pro_ID='+document.ss.Pro_ID.value+'&Reg_ID='+document.ss.Reg_ID.value,'passWrong',15);			
	}      
	
	function postAxLog (url,valores, capa, alto) {
	   var ajax=creaAjax();
	   var capaContenedora = document.getElementById(capa);
	
	/*Creamos y ejecutamos la instancia si el metodo elegido es POST*/
	
		ajax.open ('POST', url, true);
		ajax.onreadystatechange = function() {
			 if (ajax.readyState==1) {
					 capaContenedora.innerHTML="<table width=\"100%\"><tr><td align=\"center\" valign=\"middle\" height=\""+alto+"\"><img src=\"images\\indicatortext.gif\" width=\"80\" height=\"16\" border=0></td></tr></table>";
			 }
			 else if (ajax.readyState==4){
				if(ajax.status==200)
				{
					 document.getElementById(capa).innerHTML=ajax.responseText; 
				}
				else if(ajax.status==404)
					 {
	
						 capaContenedora.innerHTML = "La direccion no existe";
					 }
				 else
					 {
						 capaContenedora.innerHTML = "Error: " + ajax.status + " " + ajax.responseText;
					 }
			}
		}
		ajax.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		ajax.send(valores);
		return;
	}
</script>
<script>	
	function subir_foto_form()
	{
		$("#mensaje").html("<img src='images/indicator.gif'>");
		
		
    	var formData = new FormData(document.getElementById("formuploadajax"));
        formData.append("dato", "valor");
        $.ajax({
                url: "foreman_registro_actividad_asistencia_foto.php",
                type: "post",
                dataType: "html",
                data: formData,
                cache: false,
                contentType: false,
	     		processData: false
            }).done(function(res){
                    $("#div_asistencia_reg").html(res);
                });       
    }
 </script> 
	
<script>
	/*function miubicacion()
	{*/
		//alert("llego");
		if ("geolocation" in navigator){ //check geolocation available
			//try to get user current location using getCurrentPosition() method
			navigator.geolocation.getCurrentPosition(function(position){
					//$("#result").html("Found your location xxx <br />Lat : "+position.coords.latitude+" </br>Lang :"+ position.coords.longitude);
					Latitud=position.coords.latitude;
					Longitud=position.coords.longitude;
				});
		}else{
			console.log("Browser doesn't support geolocation!");
		}
	//}*/
</script>
		


<style type="text/css">
	p.MsoNormal {
	margin:0cm;
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:"Times New Roman";
	}
</style>

<style type="text/css">
	<!--
	.style10 {
		color: #FF0000;
		font-size: medium;
	}
	-->
	
	td.betterhover, #tabletwo tbody tr:hover
	{
		background: LightCyan;
	}
</style>
<style type="text/css">
	<!--
	.sinput {
		font-family: Verdana, Arial, Helvetica, sans-serif;
		font-size: 10px;
	}
	-->
</style>
	<div id="result"></div>
	<div id="div_registro_res">
<?php
	//echo "llego";	
	
	$Reg_ID=-1;	

	echo "<img src='images/spacer.gif' width='16' height='16' onload=\"foreman_registro_actividad(".$Reg_ID.");\"  align='middle'/>";	
?>
	</div>
	<div id="div_registro_actividad"></div>
<?php
	require('Library/Close_Conexion.php');	
?>