<?php

	session_name("Administrador");
	session_start();
		

	if ($_SESSION["EntityID"] == "")
	{
		header("Location:sessionexpired.php"); 
	}	

	require('Library/Control_Cache.php');
	require('Library/Open_Conexion.php');
	require('Library/funciones.php');
	
	$Empleado_ID=$_SESSION["Empleado_ID"];		
	$Pro_ID=$_GET["Pro_ID"];
	$_SESSION["Pro_ID"]=$Pro_ID;
	$Reg_ID=$_GET["Reg_ID"];	
	$Estilo="";
	
	if ( isset($_GET["Fecha"]) )
		$Date_Work=$_GET["Fecha"];
	else
		$Date_Work=$_SESSION["Date_Work"];

	$Estado="";
	if ($_SESSION["EntityID"] == "Foreman")
	{
		$Estado=" readonly ";
	}
	
	//echo $Estado."<br>";
	
?> 
<table border="1" cellpadding="0" cellspacing="0" id="mitabla">
	<tr align="center">
		<td  width="30" align="center"></td><td>Employe</td><td>Hour In<br />Hour Out</td><td>Building</td><td>Floor</td><td>Area</td><td>Task</td><td>Hour Contract</td><td>Hour TM</td><td>Detail</td><td>Aprobado</td><td></td><td></td>
	</tr>
	
	<?php
		$sql = "SELECT *,ADDTIME(Hora_Ingreso, '-04:00:00.000') AS Hora_Ingreso, ADDTIME(Hora_Salida, '-04:00:00.000') AS Hora_Salida,  TIMEDIFF(Hora_Salida,Hora_Ingreso) AS Horas ";
		$sql = $sql . " FROM registro_diario rd INNER JOIN registro_diario_actividad rda ON rd.Reg_ID=rda.Reg_ID AND rd.Fecha='".$Date_Work."' ";
		$sql = $sql . " INNER JOIN task t ON rda.Task_ID=t.Task_ID AND ( t.Pro_ID= ".$Pro_ID." )";
		$sql = $sql . " INNER JOIN area_control a ON t.Area_ID=a.Area_ID ";
		$sql = $sql . " INNER JOIN floor f ON f.Floor_ID=a.Floor_ID ";
		$sql = $sql . " INNER JOIN edificios e ON e.Edificio_ID=f.Edificio_ID ";
		$sql = $sql . " INNER JOIN personal p ON p.Empleado_ID=rd.Empleado_ID ";	
		
		
		//echo $sql."<br>";													
		$result77=$bd->ejecutar($sql); 		
		$RDA_ID=-1;
		$Fila=1;
		$Empleados_ID = "-777";
		
		while (($row77 = mysql_fetch_array($result77) ))	
		{
			$Task_ID=$row77["Task_ID"];
			$Area_ID=$row77["Area_ID"];
			$Floor_ID=$row77["Floor_ID"];
			$Edificio_ID=$row77["Edificio_ID"];				
			$Horas_Contract=$row77["Horas_Contract"];
			$Horas_TM=$row77["Horas_TM"];
			$Detalles=$row77["Detalles"];
			$RDA_ID=$row77["RDA_ID"];
			$Nombre=$row77["Nombre"];
			$Apellido_Paterno=$row77["Apellido_Paterno"];
			$Apellido_Materno=$row77["Apellido_Materno"];
			$Empleado_ID=$row77["Empleado_ID"];
			
			$Hora_Ingreso=$row77["Hora_Ingreso"];
			$Hora_Salida=$row77["Hora_Salida"];
			$Verificado_Foreman=$row77["Verificado_Foreman"];
			$Reg_ID=$row77["Reg_ID"];
			
			$Horas_aux=$row["Horas"];
			
			/*$sql = "select  TIMEDIFF(Hora_Salida,Hora_Ingreso) AS Horas FROM registro_diario WHERE Reg_ID=".$Reg_ID;														
			$result=$bd->ejecutar($sql); 		
			if (($row = mysql_fetch_array($result) ))	
			{
				$Horas_aux=$row["Horas"];
			}
			mysql_free_result($result);
			//echo $sql; */
			
			//En nuestro ejemplo
			$array = split(":", $Horas_aux);
			
			if ( $array[1]<31 )
				$Horas=$array[0]+0.5;
			else
				$Horas=$array[0]+1;	
			
			
			$Empleados_ID = $Empleados_ID .",". $Empleado_ID ;
						
			$_SESSION["RDA_ID"]=$RDA_ID;
			
			$estado_foreman="";
			if ( ($Verificado_Foreman=="1") || ($Verificado_Foreman==true))
			{
				//echo $Verificado_Foreman."<br>";
				$estado_foreman="checked='checked'";
			}
			
			$Nombre_Empleado=$Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno;	
			
			if (($Hora_Ingreso=="-04:00:00")	|| ($Hora_Ingreso=="00:00:00"))						
				$Hora_Ingreso="";
				
			if (($Hora_Salida=="-04:00:00")	|| ($Hora_Salida=="00:00:00"))								
				$Hora_Salida="";	
	?>
	
			<tr>
				<td width="30" align="center"><?php echo $Fila; ?></td>
				<td><?php echo $Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno; ?></td>
				<td>					
                    <input name="Hora_Ingreso_<?php echo $Fila; ?>" id="Hora_Ingreso_<?php echo $Fila; ?>" type="text" value="<?php echo $Hora_Ingreso; ?>" size="6" <?php echo $Estado; ?>><br />
					<input name="Hora_Salida_<?php echo $Fila; ?>" id="Hora_Salida_<?php echo $Fila; ?>" type="text" value="<?php echo $Hora_Salida; ?>" size="6" <?php echo $Estado; ?>>
				</td>
				<td width="100">			
					<?php	
						$Cantidad=0;
						$sql = "select COUNT(*) AS Cantidad FROM edificios WHERE Pro_ID=".$Pro_ID;														
						$result=$bd->ejecutar($sql); 		
						if (($row = mysql_fetch_array($result) ))	
						{
							$Cantidad=$row["Cantidad"];
						}
						mysql_free_result($result);
						//echo $sql."<br>"; 	
						//echo $Cantidad."<br>"; 
						if ($Cantidad>1)
						{
							$eligio="No";	
					?>		
							<select name="Edificio_ID_<?php echo $Fila; ?>" size="1"  class="cuadro" id="Edificio_ID_<?php echo $Fila; ?>" onchange="foreman_registro_actividad_piso(this.value,<?php echo $Fila; ?>,<?php echo $RDA_ID; ?>);"> 
							<option value="-1">---Select one ---</option>   
					<?php		
							$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
							$result=$bd->ejecutar($sql); 		
							while (($row = mysql_fetch_array($result) ))	
							{	
								if ($Edificio_ID==$row["Edificio_ID"])
								{
									$estado="selected='selected'";
									$eligio="Si";
								}
								else
									$estado="";
					?>
								<option value="<?php echo $row["Edificio_ID"];?>"  <?php echo $estado;?> ><?php echo $row["Nombre"];?></option>  
					<?php
							}
							mysql_free_result($result);	
					?>					
							</select> 
							<?php
							if ($eligio=="Si")
							{
						?>		
								<img src="images/spacer.gif" onload="foreman_registro_actividad_piso(<?php echo $Edificio_ID;?>,<?php echo $Fila; ?>,<?php echo $RDA_ID; ?>);" />
						<?php
							}							
					
						}
						else
						{					   
							$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
							$result=$bd->ejecutar($sql); 		
							if (($row = mysql_fetch_array($result) ))	
							{	
								$_SESSION["RDA_ID"]=-1;
					?>
								<input type="text" value="<?php echo $row["Nombre"];?>" />
								<input type="hidden" id="Edificio_ID_<?php echo $Fila; ?>" name="Edificio_ID_<?php echo $Fila; ?>" value="<?php echo $row["Edificio_ID"];?>" />
								<img src="images/spacer.gif" onload="foreman_registro_actividad_piso(<?php echo $row["Edificio_ID"];?>,<?php echo $Fila; ?>,<?php echo $RDA_ID; ?>);" />	 
								
					<?php
							}
							mysql_free_result($result);	
					
						}
					?>				</td>				
				<td width="100">	
					<div id="div_registro_actividad_piso_<?php echo $Fila; ?>"></div>				</td>
				<td width="100">	
					<div id="div_registro_actividad_area_<?php echo $Fila; ?>"></div>				</td>
				<td width="100">	
					<div id="div_registro_actividad_task_<?php echo $Fila; ?>"></div>				</td>			
				<td width="100"><input name="Horas_Contract_<?php echo $Fila; ?>" id="Horas_Contract_<?php echo $Fila; ?>" value="<?php echo $Horas_Contract; ?>" size="5" /></td>		
				<td width="100"><input name="Horas_TM_<?php echo $Fila; ?>" id="Horas_TM_<?php echo $Fila; ?>"   value="<?php echo $Horas_TM; ?>"  size="5" /></td>
				<td width="100"><input name="Detalle_<?php echo $Fila; ?>" id="Detalle_<?php echo $Fila; ?>" value="<?php echo $Detalles; ?>"  />
								<input type="hidden" name="Reg_ID_<?php echo $Fila; ?>" id="Reg_ID_<?php echo $Fila; ?>" value="<?php echo $Reg_ID; ?>" />
								<input type="hidden" name="RDA_ID_<?php echo $Fila; ?>" id="RDA_ID_<?php echo $Fila; ?>" value="<?php echo $RDA_ID; ?>" />
								<input type="hidden" name="Empleado_ID_<?php echo $Fila; ?>" id="Empleado_ID_<?php echo $Fila; ?>" value="<?php echo $Empleado_ID; ?>" />				
				</td>
				<td ><input type="checkbox" name="Verificado_Foreman_<?php echo $Fila; ?>" id="Verificado_Foreman_<?php echo $Fila; ?>" <?php echo $estado_foreman; ?> /></td>
				<td>
					<img src="images/copy_16.gif" width="32" height="32" onclick="foreman_registro_actividad_clonar(<?php echo $Empleado_ID; ?>,'<?php echo $Nombre_Empleado; ?>','<?php echo $Hora_Ingreso; ?>','<?php echo $Hora_Salida; ?>',<?php echo $Pro_ID; ?>,<?php echo $Reg_ID; ?>,-1,<?php echo $Fila; ?>)" />                    
				</td>
                <td>
                	<div id="div_registro_borrar_<?php echo $Fila; ?>">
	                	<img src="images/icon_delete.jpg" onClick="foreman_registro_actividad_borrarr(<?php echo $RDA_ID; ?>,<?php echo $Reg_ID; ?>,<?php echo $Pro_ID; ?>,<?php echo $Fila; ?>);">
    				</div>
                </td>
			</tr>
	<?php
			$Fila++;
			
		}
		mysql_free_result($result77);
		
		//$Empleados_ID = $Empleados_ID . ",-1";
		
		/*$consulta = "SELECT pr.Pro_ID, p.Nombre, p.Apellido_Paterno, p.Apellido_Materno, p.Empleado_ID, ADDTIME(rd.Hora_Ingreso, '-04:00:00.000') as Hora_Ingreso, ADDTIME(rd.Hora_Salida, '-04:00:00.000') as Hora_Salida, rd.Reg_ID, TIMEDIFF(Hora_Salida,Hora_Ingreso) AS Horas ";
		
		$consulta = $consulta . " FROM actividades a ";
		
		$consulta = $consulta . " INNER JOIN tipo_actividad ta ON a.Tipo_Actividad_ID=ta.Tipo_Actividad_ID AND ((a.Fecha=CURDATE()) OR a.Fecha='2013-01-01') ";
		$consulta = $consulta . " INNER JOIN proyectos pr ON pr.Pro_ID=a.Pro_ID AND ( pr.Pro_ID= ".$Pro_ID." ) ";
		$consulta = $consulta . " INNER JOIN actividad_personal ap ON ap.Actividad_ID=a.Actividad_ID ";
		$consulta = $consulta . " INNER JOIN personal p ON p.Empleado_ID=ap.Empleado_ID AND (  p.Empleado_ID NOT IN (".$Empleados_ID.")   )";
		$consulta = $consulta . " LEFT JOIN registro_diario rd ON rd.Empleado_ID=p.Empleado_ID AND rd.Fecha=CURDATE() ";
		$consulta = $consulta . " LEFT JOIN registro_diario_actividad rda ON rd.Reg_ID=rda.RDA_ID ";		
		$consulta = $consulta . " ORDER BY p.Nombre,pr.Pro_ID,a.Tipo_Actividad_ID,a.Fecha, Hora";*/		
		
		
		$consulta = "SELECT pr.Pro_ID, p.Nombre, p.Apellido_Paterno, p.Apellido_Materno, p.Empleado_ID ";		
		$consulta = $consulta . " FROM actividades a ";		
		$consulta = $consulta . " INNER JOIN tipo_actividad ta ON a.Tipo_Actividad_ID=ta.Tipo_Actividad_ID AND ((a.Fecha='".$Date_Work."') OR a.Fecha='2013-01-01') ";
		$consulta = $consulta . " INNER JOIN proyectos pr ON pr.Pro_ID=a.Pro_ID AND ( pr.Pro_ID= ".$Pro_ID." ) ";
		$consulta = $consulta . " INNER JOIN actividad_personal ap ON ap.Actividad_ID=a.Actividad_ID ";
		$consulta = $consulta . " INNER JOIN personal p ON p.Empleado_ID=ap.Empleado_ID AND (  p.Empleado_ID NOT IN (".$Empleados_ID.")   )";				
		$consulta = $consulta . " ORDER BY p.Nombre,pr.Pro_ID,a.Tipo_Actividad_ID,a.Fecha, Hora";	
		
		//echo $consulta."<br>";													
		$result77=$bd->ejecutar($consulta); 		
		$RDA_ID=-1;		
		
		while (($row77 = mysql_fetch_array($result77) ))	
		{			
			$Nombre=$row77["Nombre"];
			$Apellido_Paterno=$row77["Apellido_Paterno"];
			$Apellido_Materno=$row77["Apellido_Materno"];
			$Empleado_ID=$row77["Empleado_ID"];
			$Nombre_Empleado=$Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno;		
			
			$Reg_ID=-1;
			$consulta = "SELECT ADDTIME(rd.Hora_Ingreso, '-04:00:00.000') AS Hora_Ingreso, ADDTIME(rd.Hora_Salida, '-04:00:00.000') as Hora_Salida, rd.Reg_ID, TIMEDIFF(Hora_Salida,Hora_Ingreso) AS Horas ";		
			$consulta = $consulta . " FROM registro_diario rd LEFT JOIN registro_diario_actividad rda ON rd.Reg_ID=rda.RDA_ID ";						
			$consulta = $consulta . " WHERE rd.Empleado_ID=". $Empleado_ID . " AND rd.Fecha='".$Date_Work."' ";
			//echo $consulta."<br>";													
			$result877=$bd->ejecutar($consulta); 			
					
			while (($row77 = mysql_fetch_array($result877) ))	
			{	
					
				$Hora_Ingreso=$row77["Hora_Ingreso"];
				$Hora_Salida=$row77["Hora_Salida"];
				$RDA_ID=$row77["RDA_ID"];
				$Reg_ID=$row77["Reg_ID"];		
				$Horas_aux=$row77["Horas"];
				
				$array = split(":", $Horas_aux);
				
				$Empleados_ID = $Empleados_ID .",". $Empleado_ID ;
			
				if ( $array[1]<31 )
					$Horas=$array[0]+0.5;
				else
					$Horas=$array[0]+1;				
				
				if (is_null($Reg_ID))
					$Reg_ID=-1;	
	
				if (is_null($RDA_ID))
					$RDA_ID=-1;					
		?>	
				<tr>
					<td align="center"><?php echo $Fila; ?></td>
					<td><?php echo $Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno; ?>				</td>
					<td>
                    	<input name="Hora_Ingreso_<?php echo $Fila; ?>" id="Hora_Ingreso_<?php echo $Fila; ?>" type="text" value="<?php echo $Hora_Ingreso; ?>" size="6" <?php echo $Estado; ?>><br />
						<input name="Hora_Salida_<?php echo $Fila; ?>" id="Hora_Salida_<?php echo $Fila; ?>" type="text" value="<?php echo $Hora_Salida; ?>" size="6" <?php echo $Estado; ?>>
					</td>
					<td width="100">			
						<?php	
							$Cantidad=0;
							$sql = "select COUNT(*) AS Cantidad FROM edificios WHERE Pro_ID=".$Pro_ID;														
							$result=$bd->ejecutar($sql); 		
							if (($row = mysql_fetch_array($result) ))	
							{
								$Cantidad=$row["Cantidad"];
							}
							mysql_free_result($result);
							//echo $sql."<br>"; 	
							//echo $Cantidad."<br>"; 
							if ($Cantidad>1)
							{	
						?>		
								<select name="Edificio_ID_<?php echo $Fila; ?>" size="1"  class="cuadro" id="Edificio_ID_<?php echo $Fila; ?>" onchange="foreman_registro_actividad_piso(this.value,<?php echo $Fila; ?>);"> 
								<option value="-1">---Select one ---</option>   
						<?php		
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
								$result=$bd->ejecutar($sql); 		
								while (($row = mysql_fetch_array($result) ))	
								{									
						?>
									<option value="<?php echo $row["Edificio_ID"];?>" ><?php echo $row["Nombre"];?></option>  
						<?php
								}
								mysql_free_result($result);	
						?>					
								</select> 
						<?php
							}
							else
							{					   
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
						?>
									<input type="text" value="<?php echo $row["Nombre"];?>" />
									<input type="hidden" id="Edificio_ID_<?php echo $Fila; ?>" name="Edificio_ID_<?php echo $Fila; ?>" value="<?php echo $row["Edificio_ID"];?>" />
									<img src="images/spacer.gif" onload="foreman_registro_actividad_piso(<?php echo $row["Edificio_ID"];?>,<?php echo $Fila; ?>,<?php echo $RDA_ID; ?>);" />	 
									
						<?php
								}
								mysql_free_result($result);	
						
							}
						?>				</td>				
					<td width="100">	
						<div id="div_registro_actividad_piso_<?php echo $Fila; ?>">
						<input type="hidden" id="Floor_ID_<?php echo $Fila; ?>" name="Floor_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>
					<td width="100">	
						<div id="div_registro_actividad_area_<?php echo $Fila; ?>">
							<input type="hidden" id="Area_ID_<?php echo $Fila; ?>" name="Area_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>
					<td width="100">	
						<div id="div_registro_actividad_task_<?php echo $Fila; ?>">
							<input type="hidden" id="Task_ID_<?php echo $Fila; ?>" name="Task_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>			
					<td width="100"><input name="Horas_Contract_<?php echo $Fila; ?>" id="Horas_Contract_<?php echo $Fila; ?>" value="<?php echo $Horas; ?>"  size="5" /></td>		
					<td width="100"><input name="Horas_TM_<?php echo $Fila; ?>" id="Horas_TM_<?php echo $Fila; ?>"  size="5" /></td>
					<td width="100"><input name="Detalle_<?php echo $Fila; ?>" id="Detalle_<?php echo $Fila; ?>" />
									<input type="hidden" name="Reg_ID_<?php echo $Fila; ?>" id="Reg_ID_<?php echo $Fila; ?>" value="<?php echo $Reg_ID; ?>" />
									<input type="hidden" name="RDA_ID_<?php echo $Fila; ?>" id="RDA_ID_<?php echo $Fila; ?>" value="<?php echo $RDA_ID; ?>" />
									<input type="hidden" name="Empleado_ID_<?php echo $Fila; ?>" id="Empleado_ID_<?php echo $Fila; ?>" value="<?php echo $Empleado_ID; ?>" />				</td>
					<td ><input type="checkbox" name="Verificado_Foreman_<?php echo $Fila; ?>" id="Verificado_Foreman_<?php echo $Fila; ?>" /></td>
					<td>					
					</td>
                    <td>
                    	<div id="div_registro_borrar_<?php echo $Fila; ?>">
                    		<img src="images/icon_delete.jpg" onClick="foreman_registro_actividad_borrarr(<?php echo $RDA_ID; ?>,<?php echo $Reg_ID; ?>,<?php echo $Pro_ID; ?>,<?php echo $Fila; ?>);">
						</div>
                    </td>
				</tr>
		<?php
				$Fila++;
			}
			mysql_free_result($result877);			
			
			/*if ($Reg_ID==-1)
			{
				
				$Hora_Ingreso="";
				$Hora_Salida="";
				$RDA_ID=-1;
				$Reg_ID=-1;		
				$Horas_aux="";				
				
				$array = split(":", $Horas_aux);
			
				if ( $array[1]<31 )
					$Horas=$array[0]+0.5;
				else
					$Horas=$array[0]+1;				
				
				if (is_null($Reg_ID))
					$Reg_ID=-1;	
	
				if (is_null($RDA_ID))
					$RDA_ID=-1;					
		?>	
				<tr>
					<td align="center"><?php echo $Fila; ?></td>
					<td>
						cc<?php echo $Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno; ?>				</td>
					<td>
						<?php echo $Hora_Ingreso; ?><br /><?php echo $Hora_Salida; ?>
					</td>
					<td width="100">			
						<?php	
							$Cantidad=0;
							$sql = "select COUNT(*) AS Cantidad FROM edificios WHERE Pro_ID=".$Pro_ID;														
							$result=$bd->ejecutar($sql); 		
							if (($row = mysql_fetch_array($result) ))	
							{
								$Cantidad=$row["Cantidad"];
							}
							mysql_free_result($result);
							//echo $sql."<br>"; 	
							//echo $Cantidad."<br>"; 
							if ($Cantidad>1)
							{	
						?>		
								<select name="Edificio_ID_<?php echo $Fila; ?>" size="1"  class="cuadro" id="Edificio_ID_<?php echo $Fila; ?>" onchange="foreman_registro_actividad_piso(this.value,<?php echo $Fila; ?>);"> 
								<option value="-1">---Select one ---</option>   
						<?php		
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
								$result=$bd->ejecutar($sql); 		
								while (($row = mysql_fetch_array($result) ))	
								{									
						?>
									<option value="<?php echo $row["Edificio_ID"];?>" ><?php echo $row["Nombre"];?></option>  
						<?php
								}
								mysql_free_result($result);	
						?>					
								</select> 
						<?php
							}
							else
							{					   
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
						?>
									<input type="text" value="<?php echo $row["Nombre"];?>" />
									<input type="hidden" id="Edificio_ID_<?php echo $Fila; ?>" name="Edificio_ID_<?php echo $Fila; ?>" value="<?php echo $row["Edificio_ID"];?>" />
									<img src="images/spacer.gif" onload="foreman_registro_actividad_piso(<?php echo $row["Edificio_ID"];?>,<?php echo $Fila; ?>,<?php echo $RDA_ID; ?>);" />	 
									
						<?php
								}
								mysql_free_result($result);	
						
							}
						?>				</td>				
					<td width="100">	
						<div id="div_registro_actividad_piso_<?php echo $Fila; ?>">
						<input type="hidden" id="Floor_ID_<?php echo $Fila; ?>" name="Floor_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>
					<td width="100">	
						<div id="div_registro_actividad_area_<?php echo $Fila; ?>">
							<input type="hidden" id="Area_ID_<?php echo $Fila; ?>" name="Area_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>
					<td width="100">	
						<div id="div_registro_actividad_task_<?php echo $Fila; ?>">
							<input type="hidden" id="Task_ID_<?php echo $Fila; ?>" name="Task_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>			
					<td width="100"><input name="Horas_Contract_<?php echo $Fila; ?>" id="Horas_Contract_<?php echo $Fila; ?>" value="<?php echo $Horas; ?>"  size="10" /></td>		
					<td width="100"><input name="Horas_TM_<?php echo $Fila; ?>" id="Horas_TM_<?php echo $Fila; ?>"  size="10" /></td>
					<td width="100"><input name="Detalle_<?php echo $Fila; ?>" id="Detalle_<?php echo $Fila; ?>" />
									<input type="hidden" name="Reg_ID_<?php echo $Fila; ?>" id="Reg_ID_<?php echo $Fila; ?>" value="<?php echo $Reg_ID; ?>" />
									<input type="hidden" name="RDA_ID_<?php echo $Fila; ?>" id="RDA_ID_<?php echo $Fila; ?>" value="<?php echo $RDA_ID; ?>" />
									<input type="hidden" name="Empleado_ID_<?php echo $Fila; ?>" id="Empleado_ID_<?php echo $Fila; ?>" value="<?php echo $Empleado_ID; ?>" />				</td>
					<td ><input type="checkbox" name="Verificado_Foreman_<?php echo $Fila; ?>" id="Verificado_Foreman_<?php echo $Fila; ?>" /></td>
					<td>					
					</td>
				</tr>
		<?php
				$Fila++;
				
			}*/	
			
			
		}
		mysql_free_result($result77);
		
		$consulta = "SELECT pr.Pro_ID, p.Nombre, p.Apellido_Paterno, p.Apellido_Materno, p.Empleado_ID ";		
		$consulta = $consulta . " FROM actividades a ";		
		$consulta = $consulta . " INNER JOIN tipo_actividad ta ON a.Tipo_Actividad_ID=ta.Tipo_Actividad_ID AND ((a.Fecha='".$Date_Work."') OR a.Fecha='2013-01-01') ";
		$consulta = $consulta . " INNER JOIN proyectos pr ON pr.Pro_ID=a.Pro_ID AND ( pr.Pro_ID= ".$Pro_ID." ) ";
		$consulta = $consulta . " INNER JOIN actividad_personal ap ON ap.Actividad_ID=a.Actividad_ID ";
		$consulta = $consulta . " INNER JOIN personal p ON p.Empleado_ID=ap.Empleado_ID AND (  p.Empleado_ID NOT IN (".$Empleados_ID.")   )";				
		$consulta = $consulta . " ORDER BY p.Nombre,pr.Pro_ID,a.Tipo_Actividad_ID,a.Fecha, Hora";	
		
		//echo $consulta."<br>";													
		$result77=$bd->ejecutar($consulta); 		
		$RDA_ID=-1;		
		
		while (($row77 = mysql_fetch_array($result77) ))	
		{			
			$Nombre=$row77["Nombre"];
			$Apellido_Paterno=$row77["Apellido_Paterno"];
			$Apellido_Materno=$row77["Apellido_Materno"];
			$Empleado_ID=$row77["Empleado_ID"];
			$Nombre_Empleado=$Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno;										
			
			$RDA_ID=-1;
			$Reg_ID=-1;
			
			$Empleados_ID = $Empleados_ID .",". $Empleado_ID ;
									
		?>	
				<tr>
					<td align="center"><?php echo $Fila; ?></td>
					<td><?php echo $Nombre. " ".$Apellido_Paterno. " ".$Apellido_Materno; ?>				</td>
					<td>
                    	<input name="Hora_Ingreso_<?php echo $Fila; ?>" id="Hora_Ingreso_<?php echo $Fila; ?>" type="text" value="" size="6"  <?php echo $Estado; ?>><br />
						<input name="Hora_Salida_<?php echo $Fila; ?>" id="Hora_Salida_<?php echo $Fila; ?>" type="text" value=""  size="6"  <?php echo $Estado; ?>>
                    </td>								
					<td width="100">			
						<?php	
							$Cantidad=0;
							$sql = "select COUNT(*) AS Cantidad FROM edificios WHERE Pro_ID=".$Pro_ID;														
							$result=$bd->ejecutar($sql); 		
							if (($row = mysql_fetch_array($result) ))	
							{
								$Cantidad=$row["Cantidad"];
							}
							mysql_free_result($result);
							//echo $sql."<br>"; 	
							//echo $Cantidad."<br>"; 
							if ($Cantidad>1)
							{	
						?>		
								<select name="Edificio_ID_<?php echo $Fila; ?>" size="1"  class="cuadro" id="Edificio_ID_<?php echo $Fila; ?>" onchange="foreman_registro_actividad_piso(this.value,<?php echo $Fila; ?>);"> 
								<option value="-1">---Select one ---</option>   
						<?php		
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
								$result=$bd->ejecutar($sql); 		
								while (($row = mysql_fetch_array($result) ))	
								{									
						?>
									<option value="<?php echo $row["Edificio_ID"];?>" ><?php echo $row["Nombre"];?></option>  
						<?php
								}
								mysql_free_result($result);	
						?>					
								</select> 
						<?php
							}
							else
							{					   
								$sql = "select Edificio_ID, Nombre FROM edificios WHERE Pro_ID=".$Pro_ID." order by Nombre";														
								$result=$bd->ejecutar($sql); 		
								if (($row = mysql_fetch_array($result) ))	
								{	
						?>
									<input type="text" value="xx<?php echo $row["Nombre"];?>xx" />
									<input type="hidden" id="Edificio_ID_<?php echo $Fila; ?>" name="Edificio_ID_<?php echo $Fila; ?>" value="<?php echo $row["Edificio_ID"];?>" />
									<img src="images/spacer.gif" onload="foreman_registro_actividad_piso(<?php echo $row["Edificio_ID"];?>,<?php echo $Fila; ?>,<?php echo $RDA_ID; ?>);" />	 
									
						<?php
								}
								mysql_free_result($result);	
						
							}
						?></td>				
					<td width="100">	
						<div id="div_registro_actividad_piso_<?php echo $Fila; ?>">
						<input type="hidden" id="Floor_ID_<?php echo $Fila; ?>" name="Floor_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>
					<td width="100">	
						<div id="div_registro_actividad_area_<?php echo $Fila; ?>">
							<input type="hidden" id="Area_ID_<?php echo $Fila; ?>" name="Area_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>
					<td width="100">	
						<div id="div_registro_actividad_task_<?php echo $Fila; ?>">
							<input type="hidden" id="Task_ID_<?php echo $Fila; ?>" name="Task_ID_<?php echo $Fila; ?>" value="-1" />
						</div>				</td>			
					<td width="100"><input name="Horas_Contract_<?php echo $Fila; ?>" id="Horas_Contract_<?php echo $Fila; ?>" value=""  size="5" /></td>		
					<td width="100"><input name="Horas_TM_<?php echo $Fila; ?>" id="Horas_TM_<?php echo $Fila; ?>"  size="5" /></td>
					<td width="100"><input name="Detalle_<?php echo $Fila; ?>" id="Detalle_<?php echo $Fila; ?>" />
									<input type="hidden" name="Reg_ID_<?php echo $Fila; ?>" id="Reg_ID_<?php echo $Fila; ?>" value="<?php echo $Reg_ID; ?>" />
									<input type="hidden" name="RDA_ID_<?php echo $Fila; ?>" id="RDA_ID_<?php echo $Fila; ?>" value="<?php echo $RDA_ID; ?>" />
									<input type="hidden" name="Empleado_ID_<?php echo $Fila; ?>" id="Empleado_ID_<?php echo $Fila; ?>" value="<?php echo $Empleado_ID; ?>" />				</td>
					<td ><input type="checkbox" name="Verificado_Foreman_<?php echo $Fila; ?>" id="Verificado_Foreman_<?php echo $Fila; ?>" /></td>
					<td>					
					</td>
                    <td>
                    	<!--<div id="div_registro_borrar_<?php echo $Fila; ?>">
                    		<img src="../images/button_edit.png" onClick="foreman_registro_actividad_editar(<?php echo $Pro_ID; ?>,<?php echo $Empleado_ID; ?>,<?php echo $Fila; ?>);">
						</div>-->
                    </td>
				</tr>
		<?php
				$Fila++;									
		}
		mysql_free_result($result77);
		
		echo "<img src='images/spacer.gif' onload='Fila=".$Fila.";' />";
	?>		
	<tr>
		<td colspan="6"></td>	
	</tr>
</table>
<div id="div_registro">
    <table>
        <tr>
            <td colspan="6" align="right">
                <button style="font-size:18px;" onclick="foreman_registro_actividad_registrar(<?php echo $Pro_ID; ?>, <?php echo $Fila--; ?>);">Save</button>			
            </td>
        </tr>
    </table>
</div>
<div id="aux_div_res"></div>

<div id="Tabla_Lista_Actividades"></div>

<!--<img src="images/spacer.gif" onload="empleado_registro_actividad_lista(<?php echo $Reg_ID; ?>);" />	-->
 
<div id="Div_Actividad_Personal_Information"></div>
	
<?php
	

	require('Library/Close_Conexion.php');	

?>